

public class Screen {

    public void display (String s) {
	System.out.println(s);
    }
}
